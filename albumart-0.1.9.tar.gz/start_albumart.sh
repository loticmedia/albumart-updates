#!/usr/bin/env bash
set -euo pipefail

# --- CONFIG ---

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
# Prefer the OTA release renderer so software updates (which swap the release dir)
# actually deliver on-screen UI changes. Fall back to the freshly-built tree when
# no release is staged (dev boxes / first boot). The renderer finds its fonts via
# SDL_GetBasePath() (the binary's own dir), and the release dir ships fonts/.
RELEASE_RENDERER="/var/lib/albumart/current/albumart_renderer"
RENDERER_BIN="$BUILD_DIR/src/renderer/albumart_renderer"
if [ -x "$RELEASE_RENDERER" ]; then
  RENDERER_BIN="$RELEASE_RENDERER"
fi
BROKER_BIN="$BUILD_DIR/metadata-broker"
ORCH_BIN="$BUILD_DIR/nowplaying-orchestrator"

SDL_DRIVER="${SDL_VIDEODRIVER:-KMSDRM}"

# Where the network-facing binaries are relocated for the albumart-net isolation
# units. albumart-net cannot traverse the 0700 build tree under /home, so the
# metadata-broker / nowplaying-orchestrator units run from here instead.
BIN_DEPLOY_DIR="/var/lib/albumart/bin"

# --- FUNCTIONS ---

log() {
  printf '[albumart-start] %s\n' "$*" >&2
}

ensure_tmp_dirs() {
  log "Ensuring /tmp/albumart exists..."
  mkdir -p /tmp/albumart
  chmod 777 /tmp/albumart || true
}

build_if_needed() {
  if [ ! -d "$BUILD_DIR" ]; then
    log "Meson build dir not found; setting up..."
    meson setup "$BUILD_DIR"
  fi

  log "Building project..."
  ninja -C "$BUILD_DIR"
}

# Atomically copy one freshly-built artifact into the relocation dir. Temp+rename
# so a unit's ExecStartPre/exec never sees a half-written binary. Never aborts the
# script (deploy failures must not stop the renderer from coming up).
deploy_one() {
  local src="$1" dst="$2"
  if [ ! -f "$src" ]; then
    log "WARN: missing $src; skipping deploy"
    return 0
  fi
  cp -f "$src" "$dst.tmp" && chmod 0755 "$dst.tmp" && mv -f "$dst.tmp" "$dst" \
    || log "WARN: failed to deploy $dst"
}

# Relocate the network-facing binaries to a stable, OTA-independent dir that the
# isolated albumart-net uid can read+exec (group albumart, 0755) but not write.
# Preserve libwiim_provider.so's RUNPATH-relative subpath ($ORIGIN/src/providers/wiim)
# so the orchestrator resolves it with no LD_LIBRARY_PATH. The metadata-broker /
# nowplaying-orchestrator systemd units run from here (see scripts/install-net-isolation.sh).
deploy_network_artifacts() {
  log "Deploying network artifacts to $BIN_DEPLOY_DIR..."
  if ! install -d -m 0755 "$BIN_DEPLOY_DIR" "$BIN_DEPLOY_DIR/src/providers/wiim" 2>/dev/null; then
    log "WARN: could not create $BIN_DEPLOY_DIR; broker/orchestrator units may not start"
    return 0
  fi
  # Keep the state dir group-traversable so albumart-net can reach settings.json.
  chmod 0755 /var/lib/albumart 2>/dev/null || true
  deploy_one "$BUILD_DIR/metadata-broker"                         "$BIN_DEPLOY_DIR/metadata-broker"
  deploy_one "$BUILD_DIR/nowplaying-orchestrator"                 "$BIN_DEPLOY_DIR/nowplaying-orchestrator"
  deploy_one "$BUILD_DIR/artwork-fetcher"                         "$BIN_DEPLOY_DIR/artwork-fetcher"
  deploy_one "$BUILD_DIR/weather-fetcher"                         "$BIN_DEPLOY_DIR/weather-fetcher"
  deploy_one "$BUILD_DIR/src/providers/wiim/libwiim_provider.so"  "$BIN_DEPLOY_DIR/src/providers/wiim/libwiim_provider.so"
}

start_broker() {
  log "Starting metadata-broker..."
  "$BROKER_BIN" &
  BROKER_PID=$!
  log "metadata-broker PID: $BROKER_PID"
}

start_orchestrator() {
  log "Starting nowplaying-orchestrator..."
  "$ORCH_BIN" &
  ORCH_PID=$!
  log "nowplaying-orchestrator PID: $ORCH_PID"
}

kill_stray_renderers() {
  # A renderer from a previous instance can outlive its parent script and keep
  # holding the KMSDRM master, which blocks our renderer with
  # "SDL_Init failed: KMSDRM not available". Clear any strays and let DRM release.
  if pgrep -f "$RENDERER_BIN" >/dev/null 2>&1; then
    log "Found stray renderer(s) holding the display; terminating..."
    pkill -TERM -f "$RENDERER_BIN" 2>/dev/null || true
    for _ in 1 2 3 4 5 6; do
      pgrep -f "$RENDERER_BIN" >/dev/null 2>&1 || break
      sleep 0.5
    done
    pkill -KILL -f "$RENDERER_BIN" 2>/dev/null || true
    sleep 1  # give DRM a moment to release the master
  fi
}

start_renderer() {
  # Retry until the renderer grabs the display: right after a restart the
  # outgoing renderer may not have released KMSDRM yet, so the first attempt(s)
  # can die immediately. Keep trying for a while instead of giving up.
  local attempt=1 max=20
  while [ "$attempt" -le "$max" ]; do
    log "Starting renderer with SDL_VIDEODRIVER=$SDL_DRIVER (attempt $attempt/$max)..."
    SDL_VIDEODRIVER="$SDL_DRIVER" "$RENDERER_BIN" &
    RENDERER_PID=$!
    log "renderer PID: $RENDERER_PID"
    sleep 3
    if kill -0 "$RENDERER_PID" 2>/dev/null; then
      log "renderer is up (PID $RENDERER_PID)."
      return 0
    fi
    wait "$RENDERER_PID" 2>/dev/null || true  # reap the failed attempt
    log "renderer exited immediately (display likely still busy); retrying in 2s..."
    attempt=$((attempt + 1))
    sleep 2
  done
  log "renderer failed to start after $max attempts; continuing without it."
  RENDERER_PID=""
  return 0
}

cleanup() {
  log "Shutting down..."
  [ -n "${BROKER_PID:-}" ] && kill "$BROKER_PID" 2>/dev/null || true
  [ -n "${ORCH_PID:-}" ] && kill "$ORCH_PID" 2>/dev/null || true
  [ -n "${RENDERER_PID:-}" ] && kill "$RENDERER_PID" 2>/dev/null || true
  # Make sure the renderer really dies so it can't orphan and keep holding the
  # KMSDRM master (which would block the next start).
  pkill -TERM -f "$RENDERER_BIN" 2>/dev/null || true
  sleep 1
  pkill -KILL -f "$RENDERER_BIN" 2>/dev/null || true
  log "Done."
  exit 0  # graceful stop -> systemd records success, not 'failed'
}

# --- MAIN ---

log "Starting album art stack from $PROJECT_DIR"

# Install the shutdown trap before starting anything so a SIGTERM during startup
# (e.g. a fast restart) still tears the renderer down cleanly.
trap cleanup INT TERM

ensure_tmp_dirs

# Optional: if you’re confident in builds, you can comment this out later
build_if_needed

# Relocate the freshly-built network binaries for the albumart-net isolation units.
# (The metadata-broker / nowplaying-orchestrator systemd units run from there as
# albumart-net; this script no longer launches them itself.)
deploy_network_artifacts

# Seed weather JSON once on boot so the renderer has something to read even
# before the orchestrator loop refreshes it. Ignore failure to avoid stopping
# the stack if the network is down.
if [ -x "$BUILD_DIR/weather-fetcher" ]; then
  log "Seeding weather JSON..."
  if ! "$BUILD_DIR/weather-fetcher"; then
    log "weather-fetcher failed during seeding (continuing without badge)"
  fi
else
  log "weather-fetcher binary not found; skipping weather seed"
fi

# NOTE: metadata-broker + nowplaying-orchestrator are now independent systemd
# units running as the isolated albumart-net uid (Tier-2 hardening). This script
# only builds + deploys them and owns the renderer + display. To roll back to the
# in-script model, re-enable these two calls and disable the units.
#   start_broker
#   start_orchestrator
kill_stray_renderers
start_renderer

log "All components started. Waiting for processes (Ctrl+C only when running manually)..."
wait
