#!/usr/bin/env bash
set -euo pipefail

# --- CONFIG ---

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
# Prefer the OTA release renderer so software updates (which swap the release dir)
# actually deliver on-screen UI changes. Fall back to the freshly-built tree when
# no release is staged (dev boxes / first boot). The renderer finds its fonts via
# SDL_GetBasePath() (the binary's own dir), and the release dir ships fonts/.
# Everything runs from the OTA release dir (so updates deliver the whole stack:
# renderer here, broker/orchestrator/fetchers via their systemd units). The build
# tree is only a fallback for a dev box / first boot before any release is staged.
RELEASE_DIR="/var/lib/albumart/current"
RELEASE_RENDERER="$RELEASE_DIR/albumart_renderer"
RENDERER_BIN="$BUILD_DIR/src/renderer/albumart_renderer"
if [ -x "$RELEASE_RENDERER" ]; then
  RENDERER_BIN="$RELEASE_RENDERER"
fi

SDL_DRIVER="${SDL_VIDEODRIVER:-KMSDRM}"

# --- FUNCTIONS ---

release_staged() { [ -x "$RELEASE_RENDERER" ]; }

log() {
  printf '[albumart-start] %s\n' "$*" >&2
}

ensure_tmp_dirs() {
  log "Ensuring /tmp/albumart exists..."
  mkdir -p /tmp/albumart
  chmod 777 /tmp/albumart || true
}

build_if_needed() {
  if [ ! -d "$BUILD_DIR" ]; then
    log "Meson build dir not found; setting up..."
    meson setup "$BUILD_DIR"
  fi

  log "Building project..."
  ninja -C "$BUILD_DIR"
}

kill_stray_renderers() {
  # A renderer from a previous instance can outlive its parent script and keep
  # holding the KMSDRM master, which blocks our renderer with
  # "SDL_Init failed: KMSDRM not available". Clear any strays and let DRM release.
  if pgrep -f "$RENDERER_BIN" >/dev/null 2>&1; then
    log "Found stray renderer(s) holding the display; terminating..."
    pkill -TERM -f "$RENDERER_BIN" 2>/dev/null || true
    for _ in 1 2 3 4 5 6; do
      pgrep -f "$RENDERER_BIN" >/dev/null 2>&1 || break
      sleep 0.5
    done
    pkill -KILL -f "$RENDERER_BIN" 2>/dev/null || true
    sleep 1  # give DRM a moment to release the master
  fi
}

start_renderer() {
  # Retry until the renderer grabs the display: right after a restart the
  # outgoing renderer may not have released KMSDRM yet, so the first attempt(s)
  # can die immediately. Keep trying for a while instead of giving up.
  local attempt=1 max=20
  while [ "$attempt" -le "$max" ]; do
    log "Starting renderer with SDL_VIDEODRIVER=$SDL_DRIVER (attempt $attempt/$max)..."
    SDL_VIDEODRIVER="$SDL_DRIVER" "$RENDERER_BIN" &
    RENDERER_PID=$!
    log "renderer PID: $RENDERER_PID"
    sleep 3
    if kill -0 "$RENDERER_PID" 2>/dev/null; then
      log "renderer is up (PID $RENDERER_PID)."
      return 0
    fi
    wait "$RENDERER_PID" 2>/dev/null || true  # reap the failed attempt
    log "renderer exited immediately (display likely still busy); retrying in 2s..."
    attempt=$((attempt + 1))
    sleep 2
  done
  log "renderer failed to start after $max attempts; continuing without it."
  RENDERER_PID=""
  return 0
}

cleanup() {
  log "Shutting down..."
  [ -n "${BROKER_PID:-}" ] && kill "$BROKER_PID" 2>/dev/null || true
  [ -n "${ORCH_PID:-}" ] && kill "$ORCH_PID" 2>/dev/null || true
  [ -n "${RENDERER_PID:-}" ] && kill "$RENDERER_PID" 2>/dev/null || true
  # Make sure the renderer really dies so it can't orphan and keep holding the
  # KMSDRM master (which would block the next start).
  pkill -TERM -f "$RENDERER_BIN" 2>/dev/null || true
  sleep 1
  pkill -KILL -f "$RENDERER_BIN" 2>/dev/null || true
  log "Done."
  exit 0  # graceful stop -> systemd records success, not 'failed'
}

# --- MAIN ---

log "Starting album art stack from $PROJECT_DIR"

# Install the shutdown trap before starting anything so a SIGTERM during startup
# (e.g. a fast restart) still tears the renderer down cleanly.
trap cleanup INT TERM

ensure_tmp_dirs

# Build only when no OTA release is staged (dev box / first boot). On a provisioned
# device everything runs from the release dir, so skipping the on-boot build keeps
# boot fast and avoids the Pi Zero's parallel-cc1 OOM. (Releases are built from an
# isolated checkout, not here.)
if release_staged; then
  log "Release staged ($RELEASE_DIR) — running from it; skipping on-boot build."
else
  log "No release staged — building from the source tree (fallback)."
  build_if_needed
fi

# Seed weather JSON once on boot so the renderer has something to read even before
# the orchestrator loop refreshes it. Prefer the release fetcher; ignore failure.
WEATHER_BIN="$RELEASE_DIR/weather-fetcher"
[ -x "$WEATHER_BIN" ] || WEATHER_BIN="$BUILD_DIR/weather-fetcher"
if [ -x "$WEATHER_BIN" ]; then
  log "Seeding weather JSON ($WEATHER_BIN)..."
  "$WEATHER_BIN" || log "weather-fetcher failed during seeding (continuing without badge)"
else
  log "weather-fetcher binary not found; skipping weather seed"
fi

# metadata-broker + nowplaying-orchestrator are independent systemd units running
# as the isolated albumart-net uid, from the release dir. This script owns only the
# build fallback, the weather seed, and the renderer + display.
kill_stray_renderers
start_renderer

log "All components started. Waiting for processes (Ctrl+C only when running manually)..."
wait
