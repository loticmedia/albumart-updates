#!/usr/bin/env bash
set -euo pipefail

# --- CONFIG ---

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
RENDERER_BIN="$BUILD_DIR/src/renderer/albumart_renderer"
BROKER_BIN="$BUILD_DIR/metadata-broker"
ORCH_BIN="$BUILD_DIR/nowplaying-orchestrator"

SDL_DRIVER="${SDL_VIDEODRIVER:-KMSDRM}"

# --- FUNCTIONS ---

log() {
  printf '[albumart-start] %s\n' "$*" >&2
}

ensure_tmp_dirs() {
  log "Ensuring /tmp/albumart exists..."
  mkdir -p /tmp/albumart
  chmod 777 /tmp/albumart || true
}

build_if_needed() {
  if [ ! -d "$BUILD_DIR" ]; then
    log "Meson build dir not found; setting up..."
    meson setup "$BUILD_DIR"
  fi

  log "Building project..."
  ninja -C "$BUILD_DIR"
}

start_broker() {
  log "Starting metadata-broker..."
  "$BROKER_BIN" &
  BROKER_PID=$!
  log "metadata-broker PID: $BROKER_PID"
}

start_orchestrator() {
  log "Starting nowplaying-orchestrator..."
  "$ORCH_BIN" &
  ORCH_PID=$!
  log "nowplaying-orchestrator PID: $ORCH_PID"
}

start_renderer() {
  log "Starting renderer with SDL_VIDEODRIVER=$SDL_DRIVER..."
  SDL_VIDEODRIVER="$SDL_DRIVER" "$RENDERER_BIN" &
  RENDERER_PID=$!
  log "renderer PID: $RENDERER_PID"
}

cleanup() {
  log "Shutting down..."
  kill "$BROKER_PID" 2>/dev/null || true
  kill "$ORCH_PID" 2>/dev/null || true
  kill "$RENDERER_PID" 2>/dev/null || true
  log "Done."
}

# --- MAIN ---

log "Starting album art stack from $PROJECT_DIR"

ensure_tmp_dirs

# Optional: if you’re confident in builds, you can comment this out later
build_if_needed

# Seed weather JSON once on boot so the renderer has something to read even
# before the orchestrator loop refreshes it. Ignore failure to avoid stopping
# the stack if the network is down.
if [ -x "$BUILD_DIR/weather-fetcher" ]; then
  log "Seeding weather JSON..."
  if ! "$BUILD_DIR/weather-fetcher"; then
    log "weather-fetcher failed during seeding (continuing without badge)"
  fi
else
  log "weather-fetcher binary not found; skipping weather seed"
fi

start_broker
start_orchestrator
start_renderer

trap cleanup INT TERM

log "All components started. Waiting for processes (Ctrl+C only when running manually)..."
wait
